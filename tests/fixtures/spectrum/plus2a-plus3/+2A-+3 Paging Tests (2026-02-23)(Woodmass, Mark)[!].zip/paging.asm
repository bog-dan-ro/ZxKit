
DO_7FFD_FIRST           equ   1
DO_1FFD_FIRST           equ   2

start                   equ   32768

                        org   start

main                    proc
      _restart          ld    a,56
                        ld    (23693),a
                        call  3435
                        ld    a,2
                        call  #1601

                        di
                        ld    bc,#7ffd
                        ld    hl,#ffff
                        ld    a,7
      _write_page_nums  out   (c),a
                        ld    (hl),a
                        dec   a
                        jp    p,_write_page_nums

                        ld    a,7
      _check_page_nums  out   (c),a
                        cp    (hl)
                        jp    nz,_paging_disabled
                        dec   a
                        jp    p,_check_page_nums

                        ld    a,16
                        out   (c),a

                        ei

                        ld    hl,(#38a0)
                        ld    de,#1ffd
                        or    a
                        sbc   hl,de
                        jp    nz,_not_plus3

                        di
                        ld    hl,ROM_checksum_bytes + 3
                        ld    d,3
      _gather_rom_chks  ld    bc,#1ffd
                        ld    a,d
                        rla
                        and   4
                        out   (c),a

                        ld    b,#7f
                        ld    a,d
                        rla
                        rla
                        rla
                        rla
                        and   16
                        out   (c),a

                        ld    a,(#3fff)
                        ld    (hl),a

                        dec   hl
                        dec   d
                        jp    p,_gather_rom_chks

                        ld    bc,#1ffd
                        ld    a,4
                        out   (c),a
                        ld    b,#7f
                        ld    a,16
                        out   (c),a

                        ; copy bank 2 to bank 6 excluding final byte which holds bank number
                        ld    a,16+6
                        out   (c),a
                        ld    hl,#8000
                        ld    de,#c000
                        ld    bc,#3fff
                        ldir
                        ld    bc,#7ffd
                        ld    a,16
                        out   (c),a
                        ei

                        ld    a,(ROM_checksum_bytes)     ; ROM 0
                        ld    d,"0"
                        cp    #8b
                        jr    z,_set_rom_version

                        inc   d
                        cp    #1f
                        jr    z,_set_rom_version

                        ld    d,"?"

      _set_rom_version  ld    a,d
                        ld    (_rom_version+6),a

                        call  print_text
                        db    22, 3, 6,  "+2A/+3 paging tests"
                        db    22, 4, 6,  "-------------------"
      _rom_version      db    22, 6, 7,  "v4.0 ROMs detected"
                        db    22, 8, 0,  "1 - Write 7FFD first, then 1FFD"
                        db    22, 10, 0, "2 - Write 1FFD first, then 7FFD"
                        db    22, 12, 0, "3 - Exit to BASIC"
                        db    255


      _key_loop         call  wait_key

                        cp    "3"
                        ret   z

                        cp    "1"
                        ld    c,DO_7FFD_FIRST
                        jr    z,_start_tests

                        cp    "2"
                        ld    c,DO_1FFD_FIRST
                        jr    z,_start_tests

                        jr    _key_loop

      _start_tests      ld    a,c
                        ld    (first_7FFD),a

                        call  main_test

                        jp    _restart

      _paging_disabled  ld    bc,#7ffd
                        ld    a,16
                        out   (c),a
                        ei
                        call  print_text
                        db    "Paging is disabled", 255
                        ret

      _not_plus3        call  print_text
                        db    "This test requires a +2A/+3", 255
                        ret

                        endp

wait_key                proc
                        xor   a
                        ld    (23560),a
      _loop             ld    a,(23560)
                        or    a
                        jr    z,_loop
                        ret
                        endp

main_test               proc
                        call  3435
                        ld    a,2
                        call  #1601

                        ld    a,-1
                        ld    (start_bank_c000),a

                        ; test 0/1/2/3
                        call  print_text
                        db    "Testing 0/1/2/3...", 255
                        ld    hl,banks_0123
                        xor   a
                        call  test_64k_banks

                        ; test 4/5/6/7
                        call  print_text
                        db    "Testing 4/5/6/7...", 255
                        ld    hl,banks_4567
                        ld    a,1
                        call  test_64k_banks

                        ; test 4/5/6/3
                        call  print_text
                        db    "Testing 4/5/6/3...", 255
                        ld    hl,banks_4563
                        ld    a,2
                        call  test_64k_banks

                        ; test 4/7/6/3
                        call  print_text
                        db    "Testing 4/7/6/3...", 255
                        ld    hl,banks_4763
                        ld    a,3
                        call  test_64k_banks

                        ld    a,16
                        call  page_bank   ; page bank 0, update sysvar for EI

                        ld    b,30
      _rnd_loop         push  bc
                        call  test_all_rom_ram
                        pop   bc
                        djnz  _rnd_loop

                        ld    bc,#7ffd
                        ld    a,16        ; turn off screen 1 if enabled before final exit
                        out   (c),a

                        call  print_text
                        db    13, "   Press any key to continue", 255
                        call  wait_key

                        ei
                        ret
                        endp

test_all_rom_ram        proc

                        ld    a,r
                        and   23
                        ld    e,a   ; e = 7ffd
                        ld    a,r
                        and   7
                        ld    d,a   ; d = 1ffd

                        push  de

                        ld    a,(first_7FFD)
                        cp    DO_7FFD_FIRST
                        jr    z,_7ffd_1st

                        call  print_text
                        db    13
                        db    "OUT 1FFD,#", 255
                        pop   de
                        push  de
                        ld    a,d
                        call  print_hex_8

                        call  print_text
                        db    6
                        db    "OUT 7FFD,#", 255
                        pop   de
                        push  de
                        ld    a,e
                        call  print_hex_8
                        ld    a,13
                        rst   16

                        di
                        ld    bc,#1ffd
                        out   (c),d
                        ld    b,#7f
                        out   (c),e
                        jr    _cont_test

      _7ffd_1st         call  print_text
                        db    13
                        db    "OUT 7FFD,#", 255
                        pop   de
                        push  de
                        ld    a,e
                        call  print_hex_8

                        call  print_text
                        db    6
                        db    "OUT 1FFD,#", 255
                        pop   de
                        push  de
                        ld    a,d
                        call  print_hex_8
                        ld    a,13
                        rst   16

                        di
                        ld    bc,#7ffd
                        out   (c),e
                        ld    b,#1f
                        out   (c),d

      _cont_test        ld    a,(#3fff)
                        ld    l,a
                        ld    a,(#7fff)
                        ld    h,a
                        ld    a,(#bfff)
                        ld    e,a
                        ld    a,(#ffff)
                        ld    d,a

                        ld    bc,#7ffd
                        ld    a,16
                        out   (c),a
                        ld    b,#1f
                        ld    a,4
                        out   (c),a
                        ei

                        ld    (banks_found),hl
                        ld    (banks_found+2),de

                        pop   de

                        bit   0,d
                        jr    nz,_special_mode

                        ; get expected ROM byte
                        ld    a,d
                        rra
                        and   2     ; bit 1 = ROM high
                        ld    c,a

                        ld    a,e
                        rra
                        rra
                        rra
                        rra
                        and   1     ; bit 0 = ROM low
                        or    c
                        ld    c,a

                        ld    ix,ROM_checksum_bytes
                        ld    b,0
                        add   ix,bc
                        ld    a,(ix+0)
                        ld    (banks_expected),a      ; expected ROM byte

                        ; get expected RAM bytes
                        ld    a,5
                        ld    (banks_expected+1),a    ; expected #7fff byte

                        ld    a,2
                        ld    (banks_expected+2),a    ; expected #bfff byte

                        ld    a,e
                        and   7
                        ld    (banks_expected+3),a    ; expected #ffff byte

                        jr    _give_results

      _special_mode     ld    a,d
                        rra
                        and   3
                        ld    h,0
                        ld    l,a
                        add   hl,hl
                        add   hl,hl
                        ld    de,banks_0123
                        add   hl,de

                        ld    de,banks_expected
                        ld    bc,4
                        ldir

      _give_results     ld    a,16
                        rst   16

                        ld    hl,banks_found
                        ld    de,banks_expected
                        ld    bc,#0402
      _check_matches    ld    a,(de)
                        cp    (hl)
                        jr    nz,_set_ink_colour
                        inc   de
                        inc   hl
                        djnz  _check_matches

                        ld    c,0

      _set_ink_colour   ld    a,c
                        rst   16

                        ld    hl,banks_found
                        ld    b,4
                        jr    _ent1
      _out1             ld    a,"/"
                        rst   16
      _ent1             ld    a,(hl)
                        call  print_rom_or_hex
                        inc   hl
                        djnz  _out1

                        call  print_text
                        db    16, 0, "  ", "expected: ", 255

                        ld    hl,banks_expected
                        ld    b,4
                        jr    _ent2
      _out2             ld    a,"/"
                        rst   16
      _ent2             ld    a,(hl)
                        call  print_rom_or_hex
                        inc   hl
                        djnz  _out2

                        ld    a,13
                        rst   16

                        ret

                        endp

print_rom_or_hex        proc
                        push  bc
                        push  de
                        push  ix

                        cp    8
                        jr    c,_digit

                        push  af
                        call  print_text
                        db    "ROM", 255
                        pop   af

                        ld    ix,ROM_checksum_bytes
                        ld    c,0
                        cp    (ix+0)
                        jr    z,_rom

                        inc   c
                        cp    (ix+1)
                        jr    z,_rom

                        inc   c
                        cp    (ix+2)
                        jr    z,_rom

                        inc   c
                        cp    (ix+3)
                        jr    z,_rom

                        ld    a,"!"       ; unknown ROM byte!
                        rst   16
                        jr    _exit

      _rom              ld    a,c

      _digit            add   a,"0"
                        rst   16

      _exit             pop   ix
                        pop   de
                        pop   bc
                        ret
                        endp

test_64k_banks          proc
                        scf
                        rla               ; enable special 64K paging

                        di
                        exx
                        ld    bc,#1ffd
                        out   (c),a

                        ld    a,(#3fff)
                        ld    l,a
                        ld    a,(#7fff)
                        ld    h,a
                        ld    a,(#bfff)
                        ld    e,a
                        ld    a,(#ffff)
                        ld    d,a

                        ld    b,#7f
                        ld    a,(start_bank_c000)
                        add   a,2
                        ld    (start_bank_c000),a
                        and   7
                        add   a,16
                        out   (c),a       ; change expected RAM at C000 when exiting 64K paging mode
                        add   a,"0" - 16
                        ex    af,af'

                        ld    b,#1f
                        ld    a,4
                        out   (c),a       ; return to 48K paging

                        ex    af,af'
                        ld    (_expectedC000+1),a

                        ld    (banks_found),hl
                        ld    (banks_found+2),de
                        ld    hl,#2758
                        exx

                        call  print_text
                        db    "found ", 255

                        ld    de,banks_found
                        ld    b,4
                        jr    _check_first

      _check_loop       ld    a,"/"
                        rst   16

      _check_first      ld    a,(de)
                        cp    (hl)
                        inc   de
                        inc   hl

                        jr    z,_out_char

                        ld    c,a
                        ld    a,16
                        rst   16
                        ld    a,2
                        rst   16
                        ld    a,c

                        cp    8
                        jr    c,_out_char   ; is a RAM bank

                        ld    a,"R"-"0"     ; display "R" for a ROM bank

      _out_char         add   a,"0"
                        rst   16

                        ld    a,16
                        rst   16
                        xor   a
                        rst   16

                        djnz  _check_loop

                        ld    a,13
                        rst   16

                        ld    ix,_page_value_1
                        ld    a,(#7fff)
                        ld    h,a
                        add   a,"0"
                        ld    (ix+1),a
                        cp    "5"
                        ld    a,0
                        jr    z,_1
                        ld    a,2
      _1                ld    (ix+0),a

                        ld    ix,_page_value_2
                        ld    a,(#bfff)
                        ld    l,a
                        add   a,"0"
                        ld    (ix+1),a
                        cp    "2"
                        ld    a,0
                        jr    z,_2
                        ld    a,2
      _2                ld    (ix+0),a

                        ld    ix,_page_value_3
                        ld    a,(#ffff)
                        add   a,"0"
                        ld    (ix+1),a
      _expectedC000     cp    "0"
                        ld    a,0
                        jr    z,_3
                        ld    a,2
      _3                ld    (ix+0),a

                        jr    nz,_wrong_config

                        or    a
                        ld    de,#0502
                        sbc   hl,de
                        ret   z

      _wrong_config     call  print_text
                        db    "Leaving 64K mode,", 13
                        db    "    expected ROM3/5/2/0"
                        db    13
                        db    "    found    ROM"

                        db    16
      _rom_value        db    0, "3/"

                        db    16
      _page_value_1     db    0, "x/"

                        db    16
      _page_value_2     db    0, "x/"

                        db    16
      _page_value_3     db    0, "x"

                        db    16, 0
                        db    13
                        db    255
                        ret

                        endp

page_bank               proc
                        push  bc
                        ld    bc,#7ffd
                        out   (c),a
                        ld    (23388),a
                        pop   bc
                        ret
                        endp

print_hex_16            proc
                        ld    a,h
                        call  print_hex_8
                        ld    a,l
                        call  print_hex_8
                        ret
                        endp

print_hex_8             proc
                        push  af
                        rra
                        rra
                        rra
                        rra
                        call  print_hex_char
                        pop   af
                        call  print_hex_char
                        ret
                        endp

print_hex_char          proc
                        and   15
                        cp    10
                        sbc   a,#69
                        daa
                        rst   16
                        ret
                        endp

print_text              proc
                        pop   de

      _loop             ld    a,(de)
                        inc   de
                        cp    255
                        jr    z,_exit
                        rst   16
                        jr    _loop

      _exit             push  de
                        ret
                        endp

oldstack                dw    0

first_7FFD              db    0
start_bank_c000         db    0

banks_0123              db    0, 1, 2, 3
banks_4567              db    4, 5, 6, 7
banks_4563              db    4, 5, 6, 3
banks_4763              db    4, 7, 6, 3

banks_found             db    0, 0, 0, 0
banks_expected          db    0, 0, 0, 0

ROM_checksum_bytes      db    0, 0, 0, 0

                        end   start


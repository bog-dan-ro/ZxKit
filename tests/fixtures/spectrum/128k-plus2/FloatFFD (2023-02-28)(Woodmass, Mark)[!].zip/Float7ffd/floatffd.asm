; This program is licensed under the GNU General Public License. See the
; file `COPYING' for details

                  org   32768

start                   proc
                        di
                        ld    bc,#7ffd
                        ld    hl,#c000
                        ld    de,#1710
                        ld    a,255
                        ld    (hl),a
                        out   (c),d
                        ld    (hl),0
                        out   (c),e
                        cp    (hl)
                        jp    nz,not_128k

                        ld    hl,#ffff
                        ld    de,#1707
      bankloop          out   (c),d
                        ld    (hl),e
                        dec   d
                        dec   e
                        jp    p,bankloop

                        ld    a,7
                        call  8859

                        ld    a,%00111111
                        ld    (23693),a
                        call  3435

                        ld    a,%00111000
                        ld    (23693),a

                        ld    a,2
                        call  #1601

                        ld    a,22
                        rst   16
                        ld    a,1
                        rst   16
                        xor   a
                        rst   16

                        ld    hl,16384
                        ld    de,22528
                        ld    a,%00010000
      floatbytes        ld    (hl),a
                        ldi
                        ld    (hl),a
                        ldi
                        ld    (hl),a
                        ldi
                        ld    (hl),a
                        ldi
                        inc   a
                        cp    %00011000
                        jr    c,floatbytes

                        ld    a,23
                        call  page_bank
                        call  copy_screen
                        xor   a
                        call  page_bank

                        di
                        ld    (oldsp+1),sp
                        ld    sp,#be00

                        ld    hl,#be00
                        ld    de,#be01
                        ld    bc,256
                        ld    a,h
                        ld    (hl),#bf
                        ldir
                        ld    i,a
                        im    2

                        call  Test

                        di
                        ld    a,#3f
                        ld    i,a
                        im    1
                        ld    iy,23610
                        ld    hl,#2758
                        exx
                        ei
                        ld    bc,0

oldsp:                  ld    sp,0
                        ret

Test                    ld    a,195
                        ld    hl,im2sync
                        ld    (#bfbf),a
                        ld    (#bfc0),hl

                        ld    hl,14365-29-10-16-6-6-6-6-6-6-6-6-16-8-7-10
                        ld    (in_read_cycle),hl

                        ei
                        halt

                        ; get here on minimum of 29 cycles
im2sync                 ei
                        pop   hl
                        ld    hl,0
                        ld    de,0
                        ld    bc,3373
                        ldir
                        inc   hl

                        ; we have synchronised to framestart here
                        di
                        ld    hl,im2handler
                        ld    (#bfc0),hl

                        ld    hl,0

                        ld    a,r   ; for int sync
                        ei
                        halt

                        ; main interrupt-driven test code runs here
                        ; needs sync code to start on exactly 29ts (19+JP) every frame (use HALT, with remaining Ts divisable by 4)

im2handler              pop   hl    ; align stack from interrupt

                        ld    hl,(in_read_cycle)
                        inc   hl
                        inc   hl
                        inc   hl
                        inc   hl
                        inc   hl
                        inc   hl
                        inc   hl
                        inc   hl
                        ld    (in_read_cycle),hl
                        call  delay

                        ld    a,#7f
                        in    a,(#fd)                 ; sample of cycle 14376; expect #FF; write #FF to port 7FFD
                        ld    (in_7ffd_result),a

                        inc   hl
                        xor   a
                        nop
                        in    a,(255)                 ; sample of cycle 14414; char at 0,13 on screen 1 (bank 7); expect #13
                        ld    (in_ff_result),a

                        ; output results

                        ld    de,in_7ffd.txt
                        call  print_string
                        ld    a,(in_7ffd_result)
                        ld    h,a
                        ld    l,#ff
                        call  compare

                        ld    de,in_ff.txt
                        call  print_string
                        ld    a,(in_ff_result)
                        ld    h,a
                        ld    l,#13
                        call  compare

                        ld    de,paged_bank.txt
                        call  print_string
                        ld    a,(#ffff)
                        ld    h,a
                        ld    l,7
                        call  compare

                        call  copy_screen

      lock              jr    lock
                        endp

page_bank               proc
                        push  bc
                        ld    bc,#7ffd
                        out   (c),a
                        pop   bc
                        ret
                        endp

copy_screen             proc
                        ld    hl,16384
                        ld    de,49152
                        ld    bc,6912
                        ldir
                        ret
                        endp

not_128k                ei
                        ld    de,not128k.txt
                        call  print_string
                        ret

; H = result byte
; L = expected result byte
compare                 proc
                        ld    a,h
                        cp    l
                        ld    a,0
                        jr    z,_br1
                        ld    a,2
      _br1              call  set_ink
                        ld    a,h
                        call  print_hex_8

                        ld    a,h
                        cp    l
                        jr    z,_exit

                        ld    de,expected.txt
                        call  print_string
                        ld    a,l
                        call  print_hex_8

      _exit             xor   a
                        call  set_ink
                        ld    a,13
                        rst   16
                        ret
                        endp

set_ink                 proc
                        push  af
                        ld    a,16
                        rst   16
                        pop   af
                        rst   16
                        ret
                        endp

print_string            proc
      _loop             ld    a,(de)
                        inc   de
                        cp    255
                        ret   z
                        rst   16
                        jr    _loop
                        endp

print_hex_16            proc
                        ld    a,h
                        call  print_hex_8
                        ld    a,l
                        call  print_hex_8
                        ret
                        endp

print_hex_8             proc
                        push  af
                        rra
                        rra
                        rra
                        rra
                        call  print_hex_char
                        pop   af
                        call  print_hex_char
                        ret
                        endp

print_hex_char          proc
                        and   15
                        cp    10
                        sbc   a,#69
                        daa
                        rst   16
                        ret
                        endp

                        include delay.asm

not128k.txt             db    "Not a 128K Spectrum", 255
expected.txt            db    13, 6, "expected: ", 255
in_7ffd.txt             db    "IN (#7FFD):", 6, 255
in_ff.txt               db    "IN (#FF):", 6, 255
paged_bank.txt          db    "Paged bank:", 6, 255
in_read_cycle           dw    0

in_7ffd_result          db    0
in_ff_result            db    0

                        end   start


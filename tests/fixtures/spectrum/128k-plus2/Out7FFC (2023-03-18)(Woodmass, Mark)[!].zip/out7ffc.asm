
                  org   32768

start             call  3435
                  ld    a,2
                  call  #1601

                  di
                  ld    (old_sp),sp
                  ld    sp,49152

                  ld    bc,#7ffd
                  ld    hl,#c000

                  out   (c),l       ; ram 0
                  ld    (hl),0      ; (#c000) = 0

                  ld    c,#fc       ; bc = #7ffc, activate paging and ULA ports

                  ld    a,16+2
                  out   (c),a       ; ram 2, border 2

                  ld    e,(hl)      ; should read first byte of this program (start) as 32768 is now mirrored at 49152
                  ld    a,(start)
                  sub   e
                  ld    (result),a  ; zero for paging pass, non-zero for fail

                  ld    c,#fd       ; bc = #7ffd
                  ld    a,16
                  out   (c),a       ; ram 0

                  ld    sp,(old_sp)
                  ei

                  ld    de,border_red.txt
                  call  print_text

                  ld    de,paging.txt
                  call  print_text

                  ld    de,passed.txt
                  ld    a,(result)
                  or    a
                  jr    z,.nxt1
                  ld    de,failed.txt

.nxt1             call  print_text
                  ret


print_text        ld    a,(de)
                  inc   de
                  cp    255
                  ret   z
                  rst   16
                  jr    print_text


border_red.txt    db    "BORDER colour should be RED",13, 13, 255
paging.txt        db    "Port #7FFD paging: ", 255
passed.txt        db    "PASSED", 13, 255
failed.txt        db    "FAILED", 13, 255

old_sp            dw    0

result            db    0

                  end   start

